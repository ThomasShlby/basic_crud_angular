import { Component } from '@angular/core';
import axios from 'axios';
import { HttpClient } from '@angular/common/http'
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  title: string = "Employee Management"
  Ename: string = ''
  Esurname: string = ''
  Eemail: string = ''
  Esearch: string = ''
  Esubmittable: boolean = true
  Eupdate: boolean = false
  form: boolean = false
  Eid: string = ''
  values:any = {}
  currentUrl:any = "https://cute-erin-ray-coat.cyclic.app/"
  Employees = [
    {_id: '0', name:'dummy', surname: 'dummy', email:'dummy@dummy.com'}
  ]
  constructor(private http: HttpClient){
    this.getData()
  }
  openForm(){
    this.form = true
  }
  closeForm(){
    this.form = false
    this.Eupdate = false
  }
  getData(){
    this.http.get(this.currentUrl).subscribe((res: any)=>{
      this.Employees = res
      console.log(res)
    })
  }
  check(){
    return this.Ename != '' && this.Esurname != '' && this.Eemail != ''
  }
  change(e:any, place:string){
    switch(place) {
      case "name":
        this.Ename = e.target.value
      break;
      case "surname":
        this.Esurname = e.target.value
      break;
      case "email":
        this.Eemail = e.target.value
      break;
      case "search":
        this.Esearch = e.target.value
      break;
    }
    if(this.check()){
      this.Esubmittable = false
    }else if(!this.check()){
      this.Esubmittable = true
    }
  }
  submit(){
    this.http.post(this.currentUrl,{
      name: this.Ename,
      surname: this.Esurname,
      email: this.Eemail
    }).subscribe((res: any)=>{
      this.getData()
      alert("Successfully new employee is added.")
    })
    this.closeForm()
  }
  
  update(){
    this.http.patch(`${this.currentUrl}${this.Eid}`,{
      name: this.Ename,
      surname: this.Esurname,
      email: this.Eemail
    }).subscribe((res: any)=>{
      this.getData()
      alert("Successfully updated.")
    })
    this.Ename = ''
    this.Esurname = ''
    this.Eemail = ''
    this.Eupdate = !this.Eupdate
    this.closeForm()
  }
  edit(name:string, surname:string, email:string, id:string){
    this.Ename = name
    this.Esurname = surname
    this.Eemail = email
    this.Eid = id
    this.Eupdate = true
    this.Esubmittable = false
    this.openForm()
  }
  delet(id:string){
    this.http.delete(`${this.currentUrl}${id}`).subscribe((res: any)=>{
      this.getData()
      alert("employee deleted.")
    })
  }
}
